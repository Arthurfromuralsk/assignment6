package kz.aitu.oop.assignment6;

public class Logistics {
    public Transport createTransport() {return null;};
    public void planDelivery () {};
}
